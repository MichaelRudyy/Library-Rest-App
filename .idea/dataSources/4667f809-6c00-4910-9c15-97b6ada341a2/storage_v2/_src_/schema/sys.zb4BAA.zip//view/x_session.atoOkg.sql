CREATE VIEW `x$session` AS
  SELECT
    `x$processlist`.`thd_id`                 AS `thd_id`,
    `x$processlist`.`conn_id`                AS `conn_id`,
    `x$processlist`.`user`                   AS `user`,
    `x$processlist`.`db`                     AS `db`,
    `x$processlist`.`command`                AS `command`,
    `x$processlist`.`state`                  AS `state`,
    `x$processlist`.`time`                   AS `time`,
    `x$processlist`.`current_statement`      AS `current_statement`,
    `x$processlist`.`statement_latency`      AS `statement_latency`,
    `x$processlist`.`progress`               AS `progress`,
    `x$processlist`.`lock_latency`           AS `lock_latency`,
    `x$processlist`.`rows_examined`          AS `rows_examined`,
    `x$processlist`.`rows_sent`              AS `rows_sent`,
    `x$processlist`.`rows_affected`          AS `rows_affected`,
    `x$processlist`.`tmp_tables`             AS `tmp_tables`,
    `x$processlist`.`tmp_disk_tables`        AS `tmp_disk_tables`,
    `x$processlist`.`full_scan`              AS `full_scan`,
    `x$processlist`.`last_statement`         AS `last_statement`,
    `x$processlist`.`last_statement_latency` AS `last_statement_latency`,
    `x$processlist`.`current_memory`         AS `current_memory`,
    `x$processlist`.`last_wait`              AS `last_wait`,
    `x$processlist`.`last_wait_latency`      AS `last_wait_latency`,
    `x$processlist`.`source`                 AS `source`,
    `x$processlist`.`trx_latency`            AS `trx_latency`,
    `x$processlist`.`trx_state`              AS `trx_state`,
    `x$processlist`.`trx_autocommit`         AS `trx_autocommit`,
    `x$processlist`.`pid`                    AS `pid`,
    `x$processlist`.`program_name`           AS `program_name`
  FROM `sys`.`x$processlist`
  WHERE ((`x$processlist`.`conn_id` IS NOT NULL) AND (`x$processlist`.`command` <> 'Daemon'));

